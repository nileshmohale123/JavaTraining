package com.yash.crude;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCrudeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCrudeApplication.class, args);
	}

}
