package com.yash.crude;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCrudeApplicationTests {

	@Test
	void contextLoads() {
	}

}
