package com.yash.collectionTask3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.stream.Collectors;

public class Test
{

	public static void main(String[] args)
	{
         ArrayList<Integer> ls1 = new ArrayList<Integer>();
                   ls1.add(12);
                   ls1.add(12);
                   ls1.add(11);
                   ls1.add(10);
                   ls1.add(13);
           System.out.println("Orignal ArrayList:-  "+ls1);
           ArrayList<Integer> ls2 = (ArrayList<Integer>) ls1.stream().distinct().collect(Collectors.toList());
        // Print the ArrayList with duplicates removed
           System.out.println("ArrayList with duplicates removed: "  + ls2);  
           Collections.sort(ls2);
           System.out.println("ArrayList print in Acesidng order:- "+ ls2 );
	}

}
