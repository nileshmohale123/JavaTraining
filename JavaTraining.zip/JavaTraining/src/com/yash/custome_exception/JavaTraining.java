package com.yash.custome_exception;

public class JavaTraining {
	int capacity;

	public static void checkcapacity(int capacity) throws InsufficinetCapacityexception {

		if (capacity > 40) {

			throw new InsufficinetCapacityexception("Incificinet Capacity...");
		} else {

			System.out.println("welcome to java Training");
		}

	}

	public static void main(String[] args) throws InsufficinetCapacityexception {

		checkcapacity(45);
	}

}
