package com.yash.custome_exception;

public class InvalidAgeException extends Exception {

	public InvalidAgeException(String string) {

		// calling the constructor of parent Exception
		super(string);
	}

}
