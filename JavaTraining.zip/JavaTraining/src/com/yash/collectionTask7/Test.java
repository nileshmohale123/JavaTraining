package com.yash.collectionTask7;

import java.util.ArrayList;
import java.util.Scanner;

public class Test 
{ 
	public static void main(String[] args) 
	{
	  ArrayList<Student1> studs = new ArrayList<Student1>();
	  for(int i=0;i<=3;i++)
	  {
		  studs.add(new Student1());
	  }
	  Scanner sc = new Scanner(System.in);
	  double firstRank;
	  double secondRank,thirdRank;
	  int i;
	  for(i=0;i<3;i++)
	  {
		  System.out.println("Enter  name of student: ");
		  studs.get(i).setName(sc.next());
		  System.out.println();
		  System.out.println("Enter Marks: ");
		  studs.get(i).setMark(sc.nextDouble());
		  sc.nextLine();
	  }
	  int position = 0;
	  firstRank = studs.get(0).getMark();
	  for(i=0;i<=3;i++)
	  {
		  if(firstRank<studs.get(i).getMark())
		  {
			  firstRank= studs.get(i).getMark();
			  position =i;
		  }
	  }
	  /*/for 2nd rank
	  secondRank = studs.get(0).getMark();
	  for(i=0;i<=3;i++)
	  {
		  if(secondRank > studs.get(i).getMark())
		  {
			  secondRank = studs.get(i).getMark();
			  position =i;
		  }
	  }*/
	  System.out.println("Student who secured first Rank is:-"+" "+studs.get(position).getName()+" and rank is ="+studs.get(position).getMark()  );
	//  System.out.println("Student who secured second Rank is:-"+" "+studs.get(position).getName()+" and rank is ="+studs.get(position).getMark()  );
	  
	}
}
