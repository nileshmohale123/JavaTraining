package com.yash.collectionTask7;

public class Student
{
	private int rollno;
	private String sname;
	private String classname;
	private int  totalmarks; // marks out of 500, total five subjects each subject marks 100. 
	private StudentMarks student_marks;
	
	public Student(int rollno, String sname, String classname, int totalmarks, StudentMarks student_marks) 
    {
		super();
		this.rollno = rollno;
		this.sname = sname;
		this.classname = classname;
		this.totalmarks = totalmarks;
		this.student_marks = student_marks;
	}

	public int getRollno() {
		return rollno;
	}

	@Override
	public String toString() {
		return "Student [rollno=" + rollno + ", sname=" + sname + ", classname=" + classname + ", totalmarks="
				+ totalmarks + ", student_marks=" + student_marks + "]";
	}

	public void setRollno(int rollno) {
		this.rollno = rollno;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getClassname() {
		return classname;
	}

	public void setClassname(String classname) {
		this.classname = classname;
	}

	public int getTotalmarks() {
		return totalmarks;
	}

	public void setTotalmarks(int totalmarks) {
		this.totalmarks = totalmarks;
	}

	public StudentMarks getStudent_marks() {
		return student_marks;
	}

	public void setStudent_marks(StudentMarks student_marks) {
		this.student_marks = student_marks;
	}

	public Student() 
	{
		super();
	}	
	
}
