package com.yash.collectionTask7;

public class MainTest
{
     public static void main(String[] args)
     {
    	 
     }
     public int firstRank()
     {
		return 0;
     }
     public int seocndRank()
     {
    	 
		return 0;
     }
     public int thirdRank()
     {
    	 
		return 0;
     }
     
}/*StudentMarks StudentMarks1 =new StudentMarks(66, 70,80,90,50);
    	 StudentMarks StudentMarks2 =new StudentMarks(63, 73,83,93,40);
    	 StudentMarks StudentMarks3 =new StudentMarks(62, 71,85,94,54);
    	 
    	Student Student1 =new Student(101,"Priya","java Training" ,401,StudentMarks1);
    	Student Student2 =new Student(102,"Ashwini","angular Training" ,402,StudentMarks2);
    	Student Student3 =new Student(103,"Om","Php Training" ,403,StudentMarks3);
    	
	    ArrayList<Student> studentlist = new ArrayList<Student>();
	                       studentlist.add(Student1);
	                       studentlist.add(Student2);
	                       studentlist.add(Student3);
	     for(Student s:studentlist)
	     
	    	 System.out.println(s);
	     
	     */
