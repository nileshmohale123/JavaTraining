package com.yash.java.customesortingbyname;

import java.util.ArrayList;
import java.util.Collections;

public class MainClass {

		public static void main(String[] args) {
       
			ArrayList<StudentData> list = new ArrayList<StudentData>();

			// Inserting data
			list.add(new StudentData(1, "Ram", 98));
			list.add(new StudentData(2, "Shyam", 84));
			list.add(new StudentData(3, "Lokesh", 90));

			Collections.sort(list);

			// Displaying data
			for (StudentData sd : list)
				System.out.println(sd.roll + " " + sd.name + " " + sd.marks);
		}
	}

