package com.yash.java.customesortingbyname;

public class StudentData implements Comparable<StudentData> {
	
	
	int roll;
    String name;
    int marks;
  
    // Constructor
    StudentData(int roll, String name, int marks)
    {
        this.roll = roll;
        this.name = name;
        this.marks = marks;
    }
  
    // overriding method to sort
    // the student data
    public int compareTo(StudentData sd)
    {
  
        // compareTo is a string method
        return this.name.compareTo(sd.name);
    }
}

