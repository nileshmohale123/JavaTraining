package com.yash.java.oopstask5;

public class D extends C {

	@Override
	void div(int a, int b) {
		System.out.println("Div: "+(a / b));
	}
}
