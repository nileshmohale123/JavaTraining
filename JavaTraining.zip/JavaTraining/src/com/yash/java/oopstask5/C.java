package com.yash.java.oopstask5;

public class C extends B {

	@Override
	void mul(int a, int b) {
		System.out.println("Mul: "+(a * b));
	}
}
