package com.yash.java.oopstask5;

public abstract class CalcAbs {
	void sum(int a, int b) {}

	void mul(int a, int b) {}

	void sub(int a, int b) {}

	void div(int a, int b) {}
}
