package com.yash.java.oopstask5;

public class B extends A {
	@Override
	void sub(int a, int b) {
		System.out.println("Sub: "+(a - b));
	}
}
