package com.yash.java.oopstask5;

public class A extends CalcAbs {

	@Override
	void sum(int a, int b) {
		System.out.println("Sum: "+(a + b));
	}

}
