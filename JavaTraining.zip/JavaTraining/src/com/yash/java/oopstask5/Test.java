package com.yash.java.oopstask5;

public class Test {
	public static void main(String[] args) {
		CalcAbs cal = new D();
		cal.sum(10, 20);
		cal.sub(20, 10);
		cal.mul(5, 10);
		cal.div(20, 10);
	}
}
