package com.yash.java.oopsTask2;

public interface Shape {
	double area();
}
