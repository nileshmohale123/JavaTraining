package com.yash.java.oopstask8;

import java.util.Date;

public class LCD extends Electronics {

	public LCD(int id, String semiconductorType, Date dateOfManufacturing) {
		super(id, semiconductorType, dateOfManufacturing);
	}

}
