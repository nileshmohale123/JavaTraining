package com.yash.java.oopstask8;

import java.util.Date;

public class Laptop extends Electronics {

	public Laptop(int id, String semiconductorType, Date dateOfManufacturing) {
		super(id, semiconductorType, dateOfManufacturing);
	}

}
