package com.yash.java.oopstask8;

import java.util.Date;

public class Mobile extends Electronics {

	public Mobile(int id, String semiconductorType, Date dateOfManufacturing) {
		super(id, semiconductorType, dateOfManufacturing);
	}

}
