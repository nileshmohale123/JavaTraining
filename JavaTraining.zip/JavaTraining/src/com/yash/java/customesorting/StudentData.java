package com.yash.java.customesorting;
//Java program to sort student
//data according to their marks
public class StudentData implements Comparable<StudentData> {

	 String name;
	    int marks;
	  
	    // Constructor
	    StudentData(String name, int marks)
	    {
	        this.name = name;
	        this.marks = marks;
	    }
	  
	    // overriding method to sort
	    // the student data
	    public int compareTo(StudentData sd)
	    {
	        return this.marks - sd.marks;
	    }
	}
	  
