package com.yash.java.customesorting;

import java.util.ArrayList;
import java.util.Collections;

public class Main {
	
		public static void main(String[] args)
		{

			ArrayList<StudentData> list
				= new ArrayList<StudentData>();

			// Inserting data
			list.add(new StudentData("Ram", 98));
			list.add(new StudentData("Shyam", 84));
			list.add(new StudentData("Lokesh", 90));

			Collections.sort(list);

			// Displaying data
			for (StudentData sd : list)
				System.out.println(sd.name + " " + sd.marks);
		}
	
}
