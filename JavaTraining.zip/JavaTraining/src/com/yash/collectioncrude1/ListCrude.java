package com.yash.collectioncrude1;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ListCrude {
	public static void main(String[] args) {
        // create
		List<String> list = new ArrayList<String>();
		list.add("Java");
		list.add("Python");
		list.add("dot net");
		list.add("salesforce");
		System.out.println(list);
		System.out.println("Output by Foreach loop....");
		for (String value : list) {
			System.out.println(value);
		}

		System.out.println("Output by Iterator....");
		Iterator<String> itr = list.iterator();
		while (itr.hasNext()) {

			String val = itr.next();

			System.out.println(val);

		}
		//delete
		System.out.println(list.size() + " " + list.contains("java") + " " + list.remove(1));
		System.out.println(list);
		//update
		list.add(1, "Mysql");
		//get
		System.out.println(list);
		System.out.println(list.size());
	}
}
