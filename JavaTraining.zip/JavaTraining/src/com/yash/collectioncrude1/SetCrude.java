package com.yash.collectioncrude1;

import java.util.HashSet;
import java.util.Set;

public class SetCrude {

	public static void main(String[] args) {
		
	Set<String> s=new HashSet<>();
	s.add("Vijay");
	s.add("Nilesh");
	s.add("Akshay");
	s.add("Vikki");
	
	
	System.out.println(s);
	
	for (String vale : s) {
	  System.out.println(vale);	
	}
	System.out.println(s.contains("nilesh")+" "+s.size());
	System.out.println(s.remove(s));
	System.out.println(s);
	
	}
}
