package com.yash.exceptiontask8;

public class PasswordFormatException extends Exception {

	public PasswordFormatException(String message) {
		super(message);
		
	}



}
