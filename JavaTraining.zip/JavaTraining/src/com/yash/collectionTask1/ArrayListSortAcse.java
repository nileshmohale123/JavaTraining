package com.yash.collectionTask1;

import java.util.ArrayList;
import java.util.Collections;

public class ArrayListSortAcse 
{

	public static void main(String[] args) 
	{
		ArrayList<String> arraylist = new ArrayList<String>();
	    arraylist.add("vA");
	    arraylist.add("ZZ");
	    arraylist.add("CC");
	    arraylist.add("FF");

	    /*Unsorted List: ArrayList content before sorting*/
	    System.out.println("Before Sorting:");
	    for(String str: arraylist){
	      System.out.println(str);
	    }

	    /* Sorting in ascending  order*/
	    Collections.sort(arraylist);
	    
	    /* Sorted List in acceding order*/
	    System.out.println("ArrayList in ascending order:");
	    for(String str: arraylist){
	      System.out.println(str);
	    }	}

}
