package com.yash.collectionTask1;

import java.util.ArrayList;
import java.util.Collections;

public class ArrayListSortDecreasing
{
	public static void main(String args[]){
	    ArrayList<String> arrList = new ArrayList<String>();
	    arrList.add("java");
	    arrList.add("cpp");
	    arrList.add("php");
	    arrList.add("angualr");

	    /*Unsorted List: ArrayList content before sorting*/
	    System.out.println("Before Sorting:");
	    for(String str: arrList){
	      System.out.println(str);
	    }

	    // Sorting in decreasing order
	    Collections.sort(arrList); //sorting in ascending order
	    Collections.reverse(arrList); //reversing the sorted list

	    // print sorted arraylist
	    System.out.println();//new line
	    System.out.println("After sorting: ");
	    for(String str: arrList){
	      System.out.println(str);
	    }
	  }
}
