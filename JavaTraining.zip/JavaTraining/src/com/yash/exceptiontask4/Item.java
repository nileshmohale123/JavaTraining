package com.yash.exceptiontask4;
import java.util.*;
public class Item {
	private String name;
	private int price;
	private int max_no_of_items;
	
	
	public static void main(String[] args) {
		Category laptop=new Category();
		//laptop.setCategoryName("Laptop");
		laptop.setCatid(22);
		
		Category mobile=new Category();
		//mobile.setCategoryName("Mobile");
		mobile.setCatid(20);
		
		ItemBought l1=new ItemBought();
		l1.setItem_id(10);
		l1.setCategoryName("Laptop");
		l1.setCatid(20);
		
		ItemBought l2=new ItemBought();
		l2.setItem_id(11);
		l2.setCategoryName("Laptop");
		l1.setCatid(21);
		
		ItemBought m1=new ItemBought();
		m1.setCategoryName("mobile");
		m1.setCatid(12);
		l1.setCatid(22);
		
		ItemBought m2=new ItemBought();
		m2.setCategoryName("mobile");
		m2.setCatid(13);
		l1.setCatid(24);
		
		Scanner sc=new Scanner(System.in);
		
		
		ArrayList<ItemBought> al=new ArrayList<>();
		int choice=0;
		
		while(choice!=5) {
		System.out.println("Enter Your choice");
		System.out.println("1-l1");
		System.out.println("2-l2");
		System.out.println("3-m1");
		System.out.println("4-m2");
		System.out.println("5-stop");
		choice=sc.nextInt();
		
		if(choice>5 || choice<1) {
			System.out.println("Invalid choice");
		}
		else {
			switch(choice) {
			case 1:{
				System.out.println("Enter Quantity");
				int quan=sc.nextInt();
				l1.setItem_quantity(quan);
				al.add(l1);
				break;
					}
			case 2:{
				System.out.println("Enter Quantity");
				int quan=sc.nextInt();
				l2.setItem_quantity(quan);
				al.add(l2);
				break;
					}
			case 3:{
				System.out.println("Enter Quantity");
				int quan=sc.nextInt();
				m1.setItem_quantity(quan);
				al.add(m1);
				break;
					}
			case 4:{
				System.out.println("Enter Quantity");
				int quan=sc.nextInt();
				m2.setItem_quantity(quan);
				al.add(m2);
				break;
					}
			
			
				}
			}
		}
		
		
		
		sc.close();
		for(int i=0;i<al.size();i++) {
			System.out.println(al.get(i).getCategoryName());
			System.out.println(al.get(i).getCatid());
			System.out.println(al.get(i).getItem_id());
			System.out.println(al.get(i).getItem_quantity());
			
		}
	}
}
