package com.yash.collectionTask4;

import java.util.ArrayList;
import java.util.Collections;
import java.util.stream.Collectors;

public class Test
{

	public static void main(String[] args)
	{
         ArrayList<Integer> alist =new ArrayList<Integer>();
                            alist.add(20);
                            alist.add(30);
                            alist.add(30);
                            alist.add(40);
       System.out.println("Original ArrayList:- "+ alist);
       ArrayList<Integer> alist1 =  (ArrayList<Integer>) alist.stream().distinct().collect(Collectors.toList());
      System.out.println("ArrayList after Removal of Duplicates:- "+ alist1);
      
      Collections.sort(alist1,Collections.reverseOrder());
      System.out.println("Arraylist in Decending order:- "+alist1);
	}

}
