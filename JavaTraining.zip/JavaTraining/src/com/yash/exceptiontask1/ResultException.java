package com.yash.exceptiontask1;

public class ResultException extends Exception{

}
