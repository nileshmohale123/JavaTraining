package com.yash.exception;

public class InsufficinetCapacityexception extends Exception {

	public InsufficinetCapacityexception(String message) {
		super(message);
		//

	}
}
