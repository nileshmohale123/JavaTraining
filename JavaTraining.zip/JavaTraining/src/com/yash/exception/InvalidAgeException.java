package com.yash.exception;

public class InvalidAgeException extends Exception {

	public InvalidAgeException(String string) {

		// calling the constructor of parent Exception
		super(string);
	}

}
